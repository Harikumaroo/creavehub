import React from 'react'
import ReactDOM from 'react-dom/client'
import { AuthProvider } from './store/authStore'
import AppRouter from './routes/AppRouter'
import './styles/index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  </React.StrictMode>
)
