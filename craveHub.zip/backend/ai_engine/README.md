AI Engine — smoke and local testing

- Use `python manage.py ai_smoke` to run the RecommendationEngine for a local smoke user.
- Ensure a smoke user exists (mobile +919999999999) by running `python backend/smoke_tests.py`.
- To enable LLM enhancement configure `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` in your `.env` (do not commit keys).
- Local quick test (PowerShell):

```powershell
$env:OPENAI_API_KEY='sk-your-test-key'
python manage.py ai_smoke
```

- The AI chat (`AIService.food_chat`) will attempt to use LLMs if keys are present, else falls back to a rule-based response.
