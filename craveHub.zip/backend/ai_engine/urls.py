from django.urls import path
from .views import RecommendationView, FoodChatView

app_name = "ai_engine"

urlpatterns = [
    path("recommendations/", RecommendationView.as_view(), name="recommendations"),
    path("chat/",            FoodChatView.as_view(),       name="chat"),
]
