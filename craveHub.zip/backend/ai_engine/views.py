"""
CraveHub — AI Engine Views
"""

from rest_framework import status
from rest_framework.request import Request
from rest_framework.views import APIView

from core.helpers import error_response, success_response
from core.permissions import IsAuthenticatedAndActive

from .serializers import ChatMessageSerializer, RecommendationSerializer
from .services import AIService


class RecommendationView(APIView):
    """
    GET /api/v1/ai/recommendations/?context=home
    Returns personalised restaurant + menu item recommendations.
    context: home | search | post_order
    """
    permission_classes = [IsAuthenticatedAndActive]

    def get(self, request: Request):
        serializer = RecommendationSerializer(data=request.query_params)
        if not serializer.is_valid():
            return error_response("Validation failed", errors=serializer.errors)
        result = AIService.get_recommendations(
            user=request.user,
            context=serializer.validated_data.get("context", "home"),
        )
        return success_response(data=result, message="Recommendations fetched successfully")


class FoodChatView(APIView):
    """
    POST /api/v1/ai/chat/
    Food assistant chatbot endpoint.
    Body: {"message": "...", "history": [{"role": "user", "content": "..."}]}
    """
    permission_classes = [IsAuthenticatedAndActive]

    def post(self, request: Request):
        serializer = ChatMessageSerializer(data=request.data)
        if not serializer.is_valid():
            return error_response(
                "Validation failed", errors=serializer.errors,
                status_code=status.HTTP_400_BAD_REQUEST,
            )
        reply = AIService.food_chat(
            user=request.user,
            message=serializer.validated_data["message"],
            history=serializer.validated_data.get("history", []),
        )
        return success_response(
            data={"reply": reply, "role": "assistant"},
            message="Response generated",
        )
