"""
CraveHub — AI Engine Service Layer
"""

from __future__ import annotations
import logging
from django.core.cache import cache
from .recommendation import RecommendationEngine

logger = logging.getLogger(__name__)
RECO_CACHE_TTL = 60 * 3  # 3 min — short so personalisation stays fresh


class AIService:

    @staticmethod
    def get_recommendations(user, context: str = "home") -> dict:
        cache_key = f"cravehub:ai:reco:{user.id}:{context}"
        cached    = cache.get(cache_key)
        if cached:
            return cached
        result = RecommendationEngine.get_recommendations(user=user, context=context)
        cache.set(cache_key, result, RECO_CACHE_TTL)
        return result

    @staticmethod
    def invalidate_user_reco_cache(user) -> None:
        for ctx in ("home", "search", "post_order"):
            cache.delete(f"cravehub:ai:reco:{user.id}:{ctx}")

    @staticmethod
    def food_chat(user, message: str, history: list) -> str:
        """
        Simple rule-based food chat. Replace with Claude/OpenAI call in production.
        """
        msg = message.lower().strip()

        # If an LLM key is configured, try a best-effort LLM response first.
        try:
            if getattr(__import__('django').conf.settings, 'OPENAI_API_KEY', '') or getattr(__import__('django').conf.settings, 'ANTHROPIC_API_KEY', ''):
                llm_resp = AIService._call_llm_chat(user=user, message=message, history=history)
                if llm_resp:
                    return llm_resp
        except Exception:
            # fall back to rule-based chat on any failure
            pass

        if any(w in msg for w in ("hello","hi","hey")):
            name = getattr(user, "full_name", "").split()[0] or "there"
            return f"Hey {name}! What are you craving today? 🍽️"

        if any(w in msg for w in ("recommend","suggest","what should")):
            return "I'd recommend trying our trending biryanis! Check the Trending section on your home screen 🔥"

        if any(w in msg for w in ("veg","vegetarian")):
            return "We have great vegetarian options! Filter by 'Veg Only' to see all plant-based restaurants near you 🥗"

        if any(w in msg for w in ("track","order","status")):
            return "Head to the Orders tab to track your live order status in real time 📦"

        if any(w in msg for w in ("offer","coupon","discount","promo")):
            return "Check the Offers section on the home screen for today's best deals! 🏷️"

        return "I'm here to help you find great food! Ask me for recommendations, veg options, or help tracking your order 😊"

    @staticmethod
    def _call_llm_chat(user, message: str, history: list) -> str | None:
        """Best-effort LLM chat helper supporting OpenAI and Anthropic.

        Returns a plain-text reply or None on failure.
        """
        try:
            from . import prompts
            from django.conf import settings

            if getattr(settings, 'OPENAI_API_KEY', ''):
                try:
                    import openai
                    model = getattr(settings, 'OPENAI_MODEL', 'gpt-4o-mini')
                    system = prompts.CHAT_SYSTEM_PROMPT

                    # new openai client
                    if hasattr(openai, 'OpenAI'):
                        client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
                        resp = client.chat.completions.create(
                            model=model,
                            messages=[
                                {"role": "system", "content": system},
                                {"role": "user", "content": message},
                            ],
                            max_tokens=256,
                            temperature=0.6,
                        )
                        try:
                            return resp.choices[0].message.content
                        except Exception:
                            return resp['choices'][0]['message']['content']
                    else:
                        openai.api_key = settings.OPENAI_API_KEY
                        resp = openai.ChatCompletion.create(
                            model=model,
                            messages=[
                                {"role": "system", "content": system},
                                {"role": "user", "content": message},
                            ],
                            max_tokens=256,
                            temperature=0.6,
                        )
                        return resp['choices'][0]['message']['content']
                except Exception as e:
                    logger.warning('OpenAI chat failed: %s', e)

            if getattr(settings, 'ANTHROPIC_API_KEY', ''):
                try:
                    import anthropic
                    client = anthropic.Client(api_key=settings.ANTHROPIC_API_KEY)
                    prompt = prompts.CHAT_SYSTEM_PROMPT + '\n' + message
                    resp = client.complete(prompt=prompt, model=getattr(settings, 'ANTHROPIC_MODEL', 'claude-2.1'), max_tokens=200)
                    return resp.get('completion') or resp.get('text')
                except Exception as e:
                    logger.warning('Anthropic chat failed: %s', e)

        except Exception as exc:
            logger.warning('LLM chat failed preamble: %s', exc)
        return None
