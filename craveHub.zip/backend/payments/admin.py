from django.contrib import admin
from .models import Payment

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ["id", "user", "order", "razorpay_order_id", "amount", "status", "created_at"]
    list_filter  = ["status", "currency"]
    search_fields = ["user__mobile_number", "razorpay_order_id", "razorpay_payment_id"]
    readonly_fields = ["id", "razorpay_order_id", "razorpay_payment_id", "razorpay_signature", "gateway_response", "created_at", "updated_at"]
    ordering = ["-created_at"]
