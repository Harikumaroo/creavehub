from django.urls import path
from .views import InitiatePaymentView, VerifyPaymentView, PaymentHistoryView, DevSimulatePaymentView

app_name = "payments"

urlpatterns = [
    path("initiate/", InitiatePaymentView.as_view(), name="payment-initiate"),
    path("verify/",   VerifyPaymentView.as_view(),   name="payment-verify"),
    path("history/",  PaymentHistoryView.as_view(),  name="payment-history"),
    path("dev/simulate/", DevSimulatePaymentView.as_view(), name="payment-dev-simulate"),
]
