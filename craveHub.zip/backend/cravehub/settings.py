"""
CraveHub Django Settings
Production-ready, environment-variable driven.
"""
import os
from datetime import timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Load local .env from repo root when present (optional; requires python-dotenv)
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(BASE_DIR.parent, '.env'))
except Exception:
    # python-dotenv not installed or .env not present — continue using environment
    pass

# ── Core ──────────────────────────────────────────────────────
SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-in-production")
DEBUG      = os.environ.get("DEBUG", "True") == "True"
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "*").split(",")

# ── Apps ──────────────────────────────────────────────────────
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # Third-party
    "rest_framework",
    "rest_framework_simplejwt",
    "rest_framework_simplejwt.token_blacklist",
    "corsheaders",

    # CraveHub apps
    "accounts",
    "ai_engine",
    "core",
    "restaurants",
    "menu",
    "channels",
    "orders",
    "reviews",
    "banners",
    "cart",
    "categories",
    "dashboard",
    "instamart",
    "notifications",
    "offers",
    "payments",
    "search",
    "tracking",

]
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF   = "cravehub.urls"
AUTH_USER_MODEL = "accounts.User"

TEMPLATES = [
    {
        "BACKEND":  "django.template.backends.django.DjangoTemplates",
        "DIRS":     [],
        "APP_DIRS": True,
        "OPTIONS":  {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "cravehub.wsgi.application"

# ── Database (PostgreSQL) ──────────────────────────────────────
DATABASES = {
    "default": {
        "ENGINE":   "django.db.backends.postgresql",
        "NAME":     os.environ.get("DB_NAME",     "cravehub_db"),
        "USER":     os.environ.get("DB_USER",     "postgres"),
        "PASSWORD": os.environ.get("DB_PASSWORD", "root"),
        "HOST":     os.environ.get("DB_HOST",     "localhost"),
        "PORT":     os.environ.get("DB_PORT",     "5432"),
        "OPTIONS":  {"connect_timeout": 10},
        "CONN_MAX_AGE": 60,
    }
}

# ── DRF ───────────────────────────────────────────────────────
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "accounts.authentication.RevocableJWTAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],
    "DEFAULT_RENDERER_CLASSES": [
        "rest_framework.renderers.JSONRenderer",
    ],
}


#-----default rate limit---------------------------------------
RATELIMIT_USE_CACHE = "default"
RATELIMIT_ENABLE = False   # ← disables rate limiting for dev

#---CACHE-------------------------------------------------------
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
    }
}
# ── JWT ───────────────────────────────────────────────────────
SIMPLE_JWT = {
    # Access token lifetime (keep short in production). Config via JWT_ACCESS_MINUTES
    "ACCESS_TOKEN_LIFETIME":          timedelta(minutes=int(os.environ.get("JWT_ACCESS_MINUTES", 15))),
    "REFRESH_TOKEN_LIFETIME":         timedelta(days=int(os.environ.get("JWT_REFRESH_DAYS", 30))),
    "ROTATE_REFRESH_TOKENS":          True,
    "BLACKLIST_AFTER_ROTATION":       True,
    "UPDATE_LAST_LOGIN":              True,
    "ALGORITHM":                      "HS256",
    "SIGNING_KEY":                    SECRET_KEY,
    "AUTH_HEADER_TYPES":              ("Bearer",),
    "AUTH_TOKEN_CLASSES":             ("rest_framework_simplejwt.tokens.AccessToken",),
    "TOKEN_TYPE_CLAIM":               "token_type",
    "JTI_CLAIM":                      "jti",
    "USER_ID_FIELD":                  "id",
    "USER_ID_CLAIM":                  "user_id",
}

# ── CORS ──────────────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = [
    "http://localhost:5173",
]
CORS_ALLOW_CREDENTIALS = True

# ── Static & Media ────────────────────────────────────────────
STATIC_URL  = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL   = "/media/"
MEDIA_ROOT  = BASE_DIR / "media"

# ── Internationalisation ──────────────────────────────────────
LANGUAGE_CODE = "en-us"
TIME_ZONE     = "Asia/Kolkata"
USE_I18N      = True
USE_TZ        = True

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# --- Security hardening: set sensible production defaults when DEBUG is False
if not DEBUG:
    SECURE_HSTS_SECONDS = int(os.environ.get("SECURE_HSTS_SECONDS", 31536000))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = os.environ.get("SECURE_HSTS_INCLUDE_SUBDOMAINS", "True") == "True"
    SECURE_HSTS_PRELOAD = os.environ.get("SECURE_HSTS_PRELOAD", "True") == "True"
    SECURE_SSL_REDIRECT = os.environ.get("SECURE_SSL_REDIRECT", "True") == "True"
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "True") == "True"
    CSRF_COOKIE_SECURE = os.environ.get("CSRF_COOKIE_SECURE", "True") == "True"
    SECURE_BROWSER_XSS_FILTER = True
    SECURE_CONTENT_TYPE_NOSNIFF = True

# Warn if SECRET_KEY looks weak in any environment
if len(SECRET_KEY) < 50 or SECRET_KEY.startswith("change-me"):
    # Use Django's logging if available; fall back to print for early startup
    try:
        import logging
        logging.getLogger(__name__).warning(
            "Insecure SECRET_KEY detected. Set a strong SECRET_KEY via environment variables for production."
        )
    except Exception:
        print("WARNING: Insecure SECRET_KEY detected. Set a strong SECRET_KEY via environment variables for production.")

# ── SMS Gateway (plug in Twilio / MSG91 / AWS SNS) ────────────
SMS_BACKEND       = os.environ.get("SMS_BACKEND", "console")   # console | twilio | msg91
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN  = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_FROM_NUMBER = os.environ.get("TWILIO_FROM_NUMBER", "")
MSG91_AUTH_KEY     = os.environ.get("MSG91_AUTH_KEY", "")
MSG91_SENDER_ID    = os.environ.get("MSG91_SENDER_ID", "CRAVEHUB")

# ── OTP Settings ──────────────────────────────────────────────
OTP_EXPIRY_MINUTES = int(os.environ.get("OTP_EXPIRY_MINUTES", 10))
OTP_MAX_ATTEMPTS   = int(os.environ.get("OTP_MAX_ATTEMPTS", 5))
OTP_LENGTH         = int(os.environ.get("OTP_LENGTH", 6))

# ── Razorpay (Phase 3) ────────────────────────────────────────
RAZORPAY_KEY_ID     = os.environ.get("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET = os.environ.get("RAZORPAY_KEY_SECRET", "")

ASGI_APPLICATION = "cravehub.asgi.application"

# In-memory channel layer for dev. Switch to Redis for production:
# pip install channels-redis
# CHANNEL_LAYERS = {
#     "default": {
#         "BACKEND": "channels_redis.core.RedisChannelLayer",
#         "CONFIG":  {"hosts": [("127.0.0.1", 6379)]},
#     }
# }
CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels.layers.InMemoryChannelLayer",
    }
}

# If REDIS_URL is provided, use Redis channel layer in production/dev envs
REDIS_URL = os.environ.get("REDIS_URL", "")
if REDIS_URL:
    # expect redis://host:port/db
    from urllib.parse import urlparse
    url = urlparse(REDIS_URL)
    host = url.hostname or "127.0.0.1"
    port = int(url.port or 6379)
    CHANNEL_LAYERS = {
        "default": {
            "BACKEND": "channels_redis.core.RedisChannelLayer",
            "CONFIG": {"hosts": [(host, port)]},
        }
    }

# ── AI Engine (optional — plug in when ready) ─────────────────
OPENAI_API_KEY     = os.environ.get("OPENAI_API_KEY", "")
ANTHROPIC_API_KEY  = os.environ.get("ANTHROPIC_API_KEY", "")

# ── Email / SMTP (used for transactional email and optional email-to-SMS gateways)
EMAIL_BACKEND = os.environ.get("EMAIL_BACKEND", "django.core.mail.backends.smtp.EmailBackend")
EMAIL_HOST = os.environ.get("EMAIL_HOST", "")
EMAIL_PORT = int(os.environ.get("EMAIL_PORT", "587") or 587)
EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "")
EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", "True") == "True"
DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", "noreply@cravehub.local")

# Optional email-to-SMS gateway domain (e.g. 919876543210@txt.example.com)
SMS_GATEWAY_EMAIL_DOMAIN = os.environ.get("SMS_GATEWAY_EMAIL_DOMAIN", "")

# --- Sentry (optional) -------------------------------------------------
SENTRY_DSN = os.environ.get("SENTRY_DSN", "")
if SENTRY_DSN:
    try:
        import sentry_sdk
        from sentry_sdk.integrations.django import DjangoIntegration

        sentry_sdk.init(
            dsn=SENTRY_DSN,
            integrations=[DjangoIntegration()],
            traces_sample_rate=float(os.environ.get("SENTRY_TRACES_SAMPLE_RATE", "0.0")),
            send_default_pii=os.environ.get("SENTRY_SEND_DEFAULT_PII", "False") == "True",
        )
    except Exception:
        # Do not break startup when sentry-sdk is unavailable
        pass
