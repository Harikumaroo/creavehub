"""
CraveHub — Menu Serializers (Phase 2)
"""

from rest_framework import serializers
from .models import MenuCategory, MenuItem


class MenuItemSerializer(serializers.ModelSerializer):
    effective_price = serializers.DecimalField(
        max_digits=8, decimal_places=2, read_only=True
    )
    has_discount = serializers.BooleanField(read_only=True)

    class Meta:
        model = MenuItem
        fields = [
            "id", "name", "description", "image",
            "price", "discounted_price", "effective_price",
            "has_discount", "is_veg", "is_available",
            "calories", "category", "restaurant",
        ]


class MenuCategoryWithItemsSerializer(serializers.ModelSerializer):
    items = MenuItemSerializer(many=True, read_only=True)

    class Meta:
        model = MenuCategory
        fields = ["id", "name", "display_order", "items"]
