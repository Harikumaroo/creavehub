"""
CraveHub — Instamart Models
Quick commerce / grocery delivery module.
Mirrors the food ordering structure but scoped to grocery products.
"""

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from core.models import BaseModel, SoftDeleteModel


class InstamartCategory(BaseModel):
    name          = models.CharField(max_length=100, unique=True, db_index=True)
    image         = models.URLField(max_length=500, blank=True, default="")
    display_order = models.PositiveSmallIntegerField(default=0, db_index=True)
    is_active     = models.BooleanField(default=True, db_index=True)

    class Meta:
        db_table = "instamart_categories"
        ordering = ["display_order", "name"]

    def __str__(self):
        return self.name


class InstamartStore(SoftDeleteModel):
    """
    A store/dark-store that fulfils Instamart orders.
    """
    name          = models.CharField(max_length=200, db_index=True)
    address       = models.TextField()
    city          = models.CharField(max_length=100, db_index=True)
    pincode       = models.CharField(max_length=10)
    latitude      = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude     = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    delivery_time = models.PositiveSmallIntegerField(default=15, help_text="Minutes")
    delivery_fee  = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    minimum_order = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    is_open       = models.BooleanField(default=True, db_index=True)
    is_active     = models.BooleanField(default=True, db_index=True)
    image         = models.URLField(max_length=500, blank=True, default="")

    class Meta:
        db_table = "instamart_stores"
        ordering = ["name"]
        indexes  = [
            models.Index(fields=["city", "is_active", "is_open"], name="idx_istore_city"),
        ]

    def __str__(self):
        return self.name


class InstamartProduct(BaseModel):
    """
    A grocery/FMCG product sold via Instamart.
    """
    store         = models.ForeignKey(
        InstamartStore,
        on_delete=models.CASCADE,
        related_name="products",
        db_index=True,
    )
    category      = models.ForeignKey(
        InstamartCategory,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="products",
        db_index=True,
    )
    name          = models.CharField(max_length=255, db_index=True)
    description   = models.TextField(blank=True, default="")
    brand         = models.CharField(max_length=100, blank=True, default="")
    image         = models.URLField(max_length=500, blank=True, default="")
    price         = models.DecimalField(
        max_digits=8, decimal_places=2,
        validators=[MinValueValidator(0)],
    )
    discount_price = models.DecimalField(
        max_digits=8, decimal_places=2,
        null=True, blank=True,
        validators=[MinValueValidator(0)],
    )
    unit          = models.CharField(max_length=50, default="1 unit")  # e.g. "500g", "1 L"
    stock         = models.PositiveIntegerField(default=0)
    is_available  = models.BooleanField(default=True, db_index=True)
    is_featured   = models.BooleanField(default=False, db_index=True)

    class Meta:
        db_table = "instamart_products"
        ordering = ["name"]
        indexes  = [
            models.Index(fields=["store", "is_available"],      name="idx_iprod_store_avail"),
            models.Index(fields=["category", "is_available"],   name="idx_iprod_cat_avail"),
            models.Index(fields=["name"],                       name="idx_iprod_name"),
        ]

    def __str__(self):
        return f"{self.name} ({self.store.name})"

    @property
    def effective_price(self):
        return self.discount_price if self.discount_price else self.price

    @property
    def has_discount(self):
        return self.discount_price is not None and self.discount_price < self.price
