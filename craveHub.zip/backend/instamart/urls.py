from django.urls import path
from .views import InstamartHomeView, StoreProductListView, InstamartProductDetailView

app_name = "instamart"

urlpatterns = [
    path("",                                  InstamartHomeView.as_view(),        name="home"),
    path("stores/<uuid:store_id>/products/",  StoreProductListView.as_view(),     name="store-products"),
    path("products/<uuid:pk>/",               InstamartProductDetailView.as_view(),name="product-detail"),
]
