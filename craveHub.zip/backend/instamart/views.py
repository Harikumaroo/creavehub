"""
CraveHub — Instamart Views
"""

from rest_framework.request import Request
from rest_framework.views import APIView

from core.exceptions import NotFoundError
from core.helpers import error_response, paginated_response, success_response
from core.helpers.pagination import PaginationParams
from core.permissions import AllowAny

from .services import InstamartService


class InstamartHomeView(APIView):
    """
    GET /api/v1/instamart/
    Returns stores, categories, featured products.
    Optional: ?city=Chennai
    """
    permission_classes = [AllowAny]

    def get(self, request: Request):
        city = request.query_params.get("city", "").strip() or None
        data = InstamartService.get_home(city=city)
        return success_response(data=data, message="Instamart home loaded successfully")


class StoreProductListView(APIView):
    """
    GET /api/v1/instamart/stores/<uuid>/products/
    Query params: category=<uuid>, available=true, q=milk, page=1
    """
    permission_classes = [AllowAny]

    def get(self, request: Request, store_id):
        params  = PaginationParams.from_request(request)
        filters = {
            "category":  request.query_params.get("category"),
            "available": True,
            "q":         request.query_params.get("q", "").strip() or None,
        }
        data, total = InstamartService.get_store_products(
            store_id=str(store_id), filters=filters, params=params
        )
        return paginated_response(
            data=data, page=params.page,
            page_size=params.page_size, total_count=total,
            message="Products fetched successfully",
        )


class InstamartProductDetailView(APIView):
    """
    GET /api/v1/instamart/products/<uuid>/
    """
    permission_classes = [AllowAny]

    def get(self, request: Request, pk):
        data = InstamartService.get_product(product_id=str(pk))
        if not data:
            return error_response("Product not found", status_code=404)
        return success_response(data=data, message="Product fetched successfully")
