"""
CraveHub — Instamart Service Layer
"""

from __future__ import annotations
from django.core.cache import cache
from django.db.models import Q

from .models import InstamartCategory, InstamartStore, InstamartProduct
from .serializers import (
    InstamartCategorySerializer, InstamartStoreSerializer,
    InstamartProductSerializer, InstamartProductListSerializer,
)

CACHE_TTL = 60 * 5


class InstamartService:

    @staticmethod
    def get_home(city: str | None = None) -> dict:
        cache_key = f"cravehub:instamart:home:{city or 'all'}"
        cached    = cache.get(cache_key)
        if cached:
            return cached

        stores_qs = InstamartStore.objects.filter(
            is_active=True, is_deleted=False, is_open=True
        )
        if city:
            stores_qs = stores_qs.filter(city__icontains=city)

        categories = InstamartCategory.objects.filter(
            is_active=True
        ).order_by("display_order")[:12]

        featured_products = InstamartProduct.objects.filter(
            is_available=True, is_featured=True,
            store__is_active=True, store__is_deleted=False,
        ).select_related("store", "category")[:12]

        data = {
            "stores":           InstamartStoreSerializer(stores_qs[:10], many=True).data,
            "categories":       InstamartCategorySerializer(categories, many=True).data,
            "featured_products":InstamartProductListSerializer(featured_products, many=True).data,
        }
        cache.set(cache_key, data, CACHE_TTL)
        return data

    @staticmethod
    def get_store_products(store_id: str, filters: dict, params) -> tuple:
        qs = InstamartProduct.objects.filter(
            store_id=store_id,
            store__is_active=True,
            store__is_deleted=False,
        ).select_related("category")

        if filters.get("category"):
            qs = qs.filter(category_id=filters["category"])
        if filters.get("available") is not None:
            qs = qs.filter(is_available=filters["available"])
        if filters.get("q"):
            qs = qs.filter(
                Q(name__icontains=filters["q"])
                | Q(brand__icontains=filters["q"])
                | Q(description__icontains=filters["q"])
            )

        qs    = qs.order_by("-is_featured", "name")
        total = qs.count()
        return InstamartProductListSerializer(
            qs[params.offset: params.offset + params.limit], many=True
        ).data, total

    @staticmethod
    def get_product(product_id: str) -> dict | None:
        try:
            p = InstamartProduct.objects.select_related("store", "category").get(pk=product_id)
            return InstamartProductSerializer(p).data
        except InstamartProduct.DoesNotExist:
            return None
