"""
CraveHub — Instamart Serializers
"""

from rest_framework import serializers
from .models import InstamartCategory, InstamartStore, InstamartProduct


class InstamartCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model  = InstamartCategory
        fields = ["id", "name", "image", "display_order"]


class InstamartStoreSerializer(serializers.ModelSerializer):
    class Meta:
        model  = InstamartStore
        fields = [
            "id", "name", "address", "city", "pincode",
            "delivery_time", "delivery_fee", "minimum_order",
            "is_open", "image",
        ]


class InstamartProductSerializer(serializers.ModelSerializer):
    effective_price = serializers.ReadOnlyField()
    has_discount    = serializers.ReadOnlyField()

    class Meta:
        model  = InstamartProduct
        fields = [
            "id", "name", "description", "brand", "image",
            "price", "discount_price", "effective_price",
            "has_discount", "unit", "stock",
            "is_available", "is_featured",
            "store", "category",
        ]


class InstamartProductListSerializer(serializers.ModelSerializer):
    """Lightweight for list views."""
    effective_price = serializers.ReadOnlyField()
    has_discount    = serializers.ReadOnlyField()

    class Meta:
        model  = InstamartProduct
        fields = [
            "id", "name", "brand", "image",
            "price", "discount_price", "effective_price",
            "has_discount", "unit", "stock", "is_available",
        ]
