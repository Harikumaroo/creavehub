"""
CraveHub — Search Service
Unified PostgreSQL full-text search across restaurants and menu items.
Results cached per query (5 min TTL).
"""

from __future__ import annotations
import logging
from django.core.cache import cache
from django.db.models import Q

from restaurants.models import Restaurant
from restaurants.serializers import RestaurantListSerializer
from menu.models import MenuItem
from menu.serializers import MenuItemSerializer

logger = logging.getLogger(__name__)

SEARCH_CACHE_TTL = 60 * 5


class SearchService:

    @staticmethod
    def unified_search(query: str, user=None) -> dict:
        """
        Search restaurants AND menu items in parallel.
        Persists to SearchHistory if user is authenticated.
        Results are cached per normalized query.
        """
        q = query.strip()
        if not q:
            return {
                "query": q,
                "restaurants": [],
                "menu_items": [],
                "total_restaurants": 0,
                "total_menu_items": 0,
            }

        cache_key = f"cravehub:search:{q.lower()[:80]}"
        cached    = cache.get(cache_key)

        if cached:
            if user and user.is_authenticated:
                SearchService._save_history(user, q)
            return {**cached, "query": q}

        # ── Restaurants ──────────────────────────────────────
        rest_qs = (
            Restaurant.objects
            .filter(
                Q(name__icontains=q)
                | Q(description__icontains=q)
                | Q(address__city__icontains=q),
                is_active=True,
                is_deleted=False,
            )
            .select_related("address")
            .distinct()
            .order_by("-is_featured", "-rating")[:20]
        )

        # ── Menu items ───────────────────────────────────────
        item_qs = (
            MenuItem.objects
            .filter(
                Q(name__icontains=q) | Q(description__icontains=q),
                is_available=True,
                restaurant__is_active=True,
                restaurant__is_deleted=False,
            )
            .select_related("restaurant", "category")
            .order_by("-rating", "name")[:20]
        )

        result = {
            "restaurants":        RestaurantListSerializer(rest_qs, many=True).data,
            "menu_items":         MenuItemSerializer(item_qs, many=True).data,
            "total_restaurants":  rest_qs.count(),
            "total_menu_items":   item_qs.count(),
        }

        cache.set(cache_key, result, SEARCH_CACHE_TTL)

        if user and user.is_authenticated:
            SearchService._save_history(user, q)

        return {**result, "query": q}

    @staticmethod
    def get_suggestions(query: str) -> list[str]:
        """Quick autocomplete — returns matching restaurant names."""
        if not query or len(query) < 2:
            return []
        names = (
            Restaurant.objects
            .filter(name__icontains=query, is_active=True, is_deleted=False)
            .values_list("name", flat=True)[:8]
        )
        return list(names)

    @staticmethod
    def get_history(user, limit: int = 10) -> list:
        from .models import SearchHistory
        from .serializers import SearchHistorySerializer
        qs = (
            SearchHistory.objects
            .filter(user=user)
            .order_by("-created_at")[:limit]
        )
        return SearchHistorySerializer(qs, many=True).data

    @staticmethod
    def clear_history(user) -> int:
        from .models import SearchHistory
        deleted, _ = SearchHistory.objects.filter(user=user).delete()
        return deleted

    @staticmethod
    def _save_history(user, query: str) -> None:
        from .models import SearchHistory
        try:
            SearchHistory.objects.update_or_create(
                user=user, query=query,
                defaults={"query": query},
            )
        except Exception as exc:
            logger.warning("Search history save failed: %s", exc)
