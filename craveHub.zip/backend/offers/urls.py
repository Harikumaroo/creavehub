from django.urls import path
from .views import OfferListView

app_name = "offers"

urlpatterns = [
    path("", OfferListView.as_view(), name="offer-list"),
]