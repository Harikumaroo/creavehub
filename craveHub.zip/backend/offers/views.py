"""
CraveHub — Offers Views
"""

from rest_framework.request import Request
from rest_framework.views import APIView
from core.exceptions import CraveHubBaseException
from core.helpers import error_response, success_response
from core.permissions import AllowAny
from .services import OfferService


class OfferListView(APIView):
    """
    GET /api/v1/offers/
    Returns all active, non-expired promotional offers.
    """
    permission_classes = [AllowAny]
    throttle_scope = "public"

    def get(self, request: Request):
        try:
            data = OfferService.get_active_offers()
            return success_response(data=data, message="Offers fetched successfully")
        except CraveHubBaseException as exc:
            return error_response(
                exc.message, error_code=exc.error_code, status_code=exc.status_code
            )