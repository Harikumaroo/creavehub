"""
CraveHub — Restaurants Serializers (Phase 2)
"""

from rest_framework import serializers
from .models import Restaurant, RestaurantAddress


class RestaurantAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = RestaurantAddress
        fields = [
            "address", "city", "state",
            "country", "pincode",
            "latitude", "longitude",
        ]


class RestaurantListSerializer(serializers.ModelSerializer):
    address = RestaurantAddressSerializer(read_only=True)

    class Meta:
        model = Restaurant
        fields = [
            "id", "name", "slug", "description",
            "logo", "cover_image",
            "rating", "total_reviews",
            "average_delivery_time", "minimum_order_amount",
            "delivery_fee", "is_pure_veg",
            "is_open", "is_featured", "is_active",
            "restaurant_type", "address",
        ]


class RestaurantDetailSerializer(serializers.ModelSerializer):
    address = RestaurantAddressSerializer(read_only=True)

    class Meta:
        model = Restaurant
        fields = [
            "id", "name", "slug", "description",
            "logo", "cover_image",
            "rating", "total_reviews",
            "average_delivery_time", "minimum_order_amount",
            "delivery_fee", "preparation_time", "is_pure_veg",
            "is_open", "is_featured", "is_active",
            "restaurant_type", "address",
            "created_at", "updated_at",
        ]
