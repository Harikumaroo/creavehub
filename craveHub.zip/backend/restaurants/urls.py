from django.urls import path
from .views import RestaurantDetailView, RestaurantListView

app_name = "restaurants"

urlpatterns = [
    path("", RestaurantListView.as_view(), name="restaurant-list"),
    path("<uuid:pk>/", RestaurantDetailView.as_view(), name="restaurant-detail"),
]