"""
CraveHub — Notifications Service Layer
Handles creation, delivery, and push dispatch.
"""

from __future__ import annotations
import logging
from django.db import transaction
from .models import Notification, PushToken

logger = logging.getLogger(__name__)


class NotificationService:

    # ── Creation ─────────────────────────────────────────────

    @staticmethod
    @transaction.atomic
    def send(
        user,
        title: str,
        body: str,
        notif_type: str = Notification.NotificationType.SYSTEM,
        metadata: dict | None = None,
    ) -> Notification:
        """Create an in-app notification and attempt push delivery."""
        notif = Notification.objects.create(
            user=user,
            title=title,
            body=body,
            notif_type=notif_type,
            metadata=metadata or {},
        )
        NotificationService._dispatch_push(user, title, body, metadata or {})
        return notif

    @staticmethod
    def send_order_notification(order, notif_type: str) -> None:
        """Convenience method triggered by order status changes."""
        messages = {
            "order_placed":        ("Order Placed 🎉",        f"Your order #{str(order.id)[:8].upper()} has been placed successfully!"),
            "order_confirmed":     ("Order Confirmed ✅",      f"Restaurant confirmed your order #{str(order.id)[:8].upper()}."),
            "order_preparing":     ("Preparing your food 🍳",  "Your order is being prepared. Hang tight!"),
            "order_out_delivery":  ("Out for Delivery 🛵",     "Your order is on the way!"),
            "order_delivered":     ("Delivered! 🎉",           "Your order has been delivered. Enjoy your meal!"),
            "order_cancelled":     ("Order Cancelled ❌",      f"Order #{str(order.id)[:8].upper()} has been cancelled."),
        }
        title, body = messages.get(notif_type, ("Update", "Your order status changed."))
        NotificationService.send(
            user=order.user,
            title=title,
            body=body,
            notif_type=notif_type,
            metadata={"order_id": str(order.id)},
        )

    # ── Queries ───────────────────────────────────────────────

    @staticmethod
    def get_user_notifications(user, params) -> tuple:
        qs = (
            Notification.objects
            .filter(user=user)
            .order_by("-created_at")
        )
        total  = qs.count()
        sliced = qs[params.offset: params.offset + params.limit]
        return sliced, total

    @staticmethod
    def get_unread_count(user) -> int:
        return Notification.objects.filter(user=user, is_read=False).count()

    @staticmethod
    @transaction.atomic
    def mark_read(user, notification_ids: list) -> int:
        updated = Notification.objects.filter(
            user=user, id__in=notification_ids
        ).update(is_read=True)
        return updated

    @staticmethod
    @transaction.atomic
    def mark_all_read(user) -> int:
        return Notification.objects.filter(
            user=user, is_read=False
        ).update(is_read=True)

    # ── Push Token Management ─────────────────────────────────

    @staticmethod
    def register_push_token(user, token: str, platform: str) -> PushToken:
        obj, _ = PushToken.objects.update_or_create(
            token=token,
            defaults={"user": user, "platform": platform, "is_active": True},
        )
        return obj

    @staticmethod
    def _dispatch_push(user, title: str, body: str, data: dict) -> None:
        """
        FCM push dispatch stub.
        Replace with actual firebase-admin SDK call in production:
            from firebase_admin import messaging
            messaging.send(messaging.Message(...))
        """
        tokens = PushToken.objects.filter(
            user=user, is_active=True
        ).values_list("token", flat=True)

        if not tokens:
            return

        logger.info(
            "[PUSH] To: %s | Tokens: %d | Title: %s",
            user, len(tokens), title,
        )
        # TODO: integrate firebase-admin here
